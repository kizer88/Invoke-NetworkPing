$Component = "DNS-Validator-Main"
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$dnsValidatorPath = Join-Path $scriptPath "dnsvalidator"

Write-Progress -Activity "DNS Validator Initialization" -Status "Setting up shared state" -PercentComplete 10

$script:DnsHash = [hashtable]::Synchronized(@{
        # Error Handling
        ErrorLog           = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
        ErrorCount         = 0
        PingErrors         = [hashtable]::Synchronized(@{})
    
        # Performance Settings
        Performance        = @{
            BatchSize       = 50
            MaxRunspaces    = [Math]::Min(32, [Environment]::ProcessorCount * 2)
            TimeoutMS       = 1000
            CacheExpiration = New-TimeSpan -Days 1
            RetryAttempts   = 2
        }
    
        # Validation Settings
        ValidationPriority = @{
            LocalDNS    = 1
            SCCM        = 2
            CrossDomain = 3
            Historical  = 4
        }
    
        # Cache Management
        Cache              = @{
            DNSResponses      = [hashtable]::Synchronized(@{})
            SCCMData          = [hashtable]::Synchronized(@{})
            ValidationResults = [hashtable]::Synchronized(@{})
            DomainMapping     = [hashtable]::Synchronized(@{})
        }
    
        # Collections
        DnsResults         = [System.Collections.ArrayList]::new()
        ValidationResults  = [System.Collections.ArrayList]::new()
        Verified           = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
        Orphaned           = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
        Stale              = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
        Mismatched         = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
    
        # Trust Configuration
        TrustMap           = @{
            'AUTH' = @{
                'DNSServers' = @('15.97.197.92', '15.97.196.29')
                'TrustsDown' = @('CVS', 'IM1')
                'TrustedBy'  = @()
            }
            'CVS'  = @{
                'DNSServers' = @('corsi-cvsdc02.CVS.RD.ADAPPS.HP.COM', 'corsi-cvsdc03.CVS.RD.ADAPPS.HP.COM')
                'TrustsUp'   = @('AUTH')
                'TrustedBy'  = @('AUTH')
            }
            'IM1'  = @{
                'DNSServers' = @('im1dc01.IM1.MFG.HPICORP.NET', 'im1dc02.IM1.MFG.HPICORP.NET')
                'TrustsUp'   = @('AUTH')
                'TrustedBy'  = @('AUTH')
            }
        }
    
        # Runtime paths and state
        ScriptPath         = $scriptPath
        DnsValidatorPath   = $dnsValidatorPath
        DomainDNSServers   = @{}
        Targets            = @()
        ForceRefresh       = $false
        BatchResults       = @{}
    
        # Runspace Configuration
        RunspaceConfig     = @{
            MinRunspaces = 1
            MaxRunspaces = 32
            SessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
        }
        runspacePool       = $null
    })

Write-Progress -Activity "DNS Validator Initialization" -Status "Loading components" -PercentComplete 40

try {
    # Load error handling first
    Write-Progress -Activity "DNS Validator Initialization" -Status "Loading error handling" -PercentComplete 50
    . (Join-Path $dnsValidatorPath "Add-DNSValidationError.ps1")
    
    # Load core components
    Write-Progress -Activity "DNS Validator Initialization" -Status "Loading core components" -PercentComplete 60
    $components = @(
        "Initialize-DNSRunspacePool.ps1",
        "Get-DomainDnsServers.ps1",
        "Get-TargetDomain.ps1",
        "Test-DNSValidationFunctions.ps1",
        "Invoke-DNSResolutionWorker.ps1",
        "Invoke-DNSBatchProcessor.ps1",
        "Invoke-DNSValidationProcessor.ps1"
    )

    $componentCount = $components.Count
    for ($i = 0; $i -lt $componentCount; $i++) {
        $component = $components[$i]
        $percentComplete = 60 + (($i / $componentCount) * 30)
        Write-Progress -Activity "DNS Validator Initialization" -Status "Loading component: $component" -PercentComplete $percentComplete
        . (Join-Path $dnsValidatorPath $component)
    }

    # Initialize runspace pool
    Write-Progress -Activity "DNS Validator Initialization" -Status "Initializing runspace pool" -PercentComplete 90
    Initialize-DNSRunspacePool
    
    Write-Progress -Activity "DNS Validator Initialization" -Status "Initialization complete" -PercentComplete 100
}
catch {
    Write-Progress -Activity "DNS Validator Initialization" -Status "Error during initialization" -PercentComplete 100
    Add-DNSValidationError -Target "ComponentLoad" -ErrorRecord $_ -Operation "Initialize" -Severity "Critical" -Component $Component
    throw
}

function Invoke-DNSValidator {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string[]]$Targets,
        [switch]$ForceRefresh
    )
    
    $Component = "Invoke-DNSValidator"
    Write-Progress -Activity "DNS Validation" -Status "Initializing" -PercentComplete 0
    
    if (-not $DnsHash) {
        Write-Progress -Activity "DNS Validation" -Status "Reinitializing DNS Hash" -PercentComplete 10
        . (Join-Path $dnsValidatorPath "Initialize-DNSRunspacePool.ps1")
        . (Join-Path $dnsValidatorPath "DNS-Config.ps1")
        . (Join-Path $dnsValidatorPath "Add-DNSValidationError.ps1")
        Validate-DnsHashIntegrity -DnsHash $DnsHash
    }
    
    Write-Progress -Activity "DNS Validation" -Status "Processing Targets" -PercentComplete 20
    $dnsHash.Targets = $Targets

    # Start DNS Resolution Workers
    $totalTargets = $DnsHash.Targets.Count
    for ($i = 0; $i -lt $totalTargets; $i++) {
        $percentComplete = 20 + (($i / $totalTargets) * 40)
        Write-Progress -Activity "DNS Validation" -Status "Processing Target $($i+1) of $totalTargets" -PercentComplete $percentComplete
        
        $target = $DnsHash.Targets[$i]
        $DnsHash.Target = $target
        $domain = Get-TargetDomain -Target $DnsHash.Target
        Invoke-DNSResolutionWorker -Target $target -Domain $domain -RunspacePool $DnsHash.runspacePool -ForceRefresh:$ForceRefresh
    }
    
    Write-Progress -Activity "DNS Validation" -Status "Waiting for Jobs to Complete" -PercentComplete 60
    
    # Process jobs and collect results
    $jobKeys = $DnsHash.Keys | Where-Object { $_ -like 'Job_*' }
    $totalJobs = $jobKeys.Count
    $completedJobs = 0
    
    foreach ($jobKey in $jobKeys) {
        $percentComplete = 60 + (($completedJobs / $totalJobs) * 30)
        Write-Progress -Activity "DNS Validation" -Status "Processing Job $($completedJobs+1) of $totalJobs" -PercentComplete $percentComplete

        $jobEntry = $DnsHash[$jobKey]
        $result = $jobEntry.PowerShell.EndInvoke($jobEntry.Job)
        $jobEntry.PowerShell.Dispose()
        
        switch ($result.Status) {
            "Verified" { [void]$DnsHash.Verified.Add($result) }
            "Mismatched" { [void]$DnsHash.Mismatched.Add($result) }
            "Error" { 
                [void]$DnsHash.ErrorLog.Add(@{
                        Target    = $result.Target
                        Details   = $result.Details
                        Timestamp = $result.Timestamp
                    })
            }
        }
        
        $DnsHash.Remove($jobKey)
        $completedJobs++
    }
    
    Write-Progress -Activity "DNS Validation" -Status "Aggregating Results" -PercentComplete 90
    
    $results = @{
        Summary = @{
            Verified   = $DnsHash.Verified.Count
            Orphaned   = $DnsHash.Orphaned.Count
            Stale      = $DnsHash.Stale.Count
            Mismatched = $DnsHash.Mismatched.Count
            Total      = $DnsHash.Targets.Count
        }
        Results = @{
            Verified   = $DnsHash.Verified
            Orphaned   = $DnsHash.Orphaned
            Stale      = $DnsHash.Stale
            Mismatched = $DnsHash.Mismatched
        }
    }
    
    Write-Progress -Activity "DNS Validation" -Status "Complete" -PercentComplete 100
    return $results
}

function Validate-DnsHashIntegrity {
    param([hashtable]$DnsHash)
    
    Write-Progress -Activity "DNS Hash Validation" -Status "Checking required keys" -PercentComplete 0
    
    $requiredKeys = @(
        @{ Key = 'ErrorLog'; Type = 'ArrayList' },
        @{ Key = 'ErrorCount'; Type = 'Int' },
        @{ Key = 'PingErrors'; Type = 'Hashtable' },
        @{ Key = 'Performance'; Type = 'Hashtable' },
        @{ Key = 'ValidationPriority'; Type = 'Hashtable' },
        @{ Key = 'Cache'; Type = 'Hashtable' },
        @{ Key = 'TrustMap'; Type = 'Hashtable' },
        @{ Key = 'RunspaceConfig'; Type = 'Hashtable' }
    )
    
    $keyCount = $requiredKeys.Count
    for ($i = 0; $i -lt $keyCount; $i++) {
        $requirement = $requiredKeys[$i]
        $key = $requirement.Key
        $percentComplete = ($i / $keyCount) * 50
        Write-Progress -Activity "DNS Hash Validation" -Status "Validating key: $key" -PercentComplete $percentComplete
        
        if (-not $DnsHash.ContainsKey($key) -or $null -eq $DnsHash[$key]) {
            Write-Warning "DnsHash key '$key' is missing or null"
            continue
        }

        # Verify the type and structure of each key
        $value = $DnsHash[$key]
        switch ($requirement.Type) {
            'ArrayList' {
                if (-not ($value -is [System.Collections.ArrayList])) {
                    Write-Warning "DnsHash key '$key' should be an ArrayList but is $($value.GetType().Name)"
                }
            }
            'Hashtable' {
                if (-not ($value -is [hashtable])) {
                    Write-Warning "DnsHash key '$key' should be a Hashtable but is $($value.GetType().Name)"
                }
            }
            'Int' {
                if (-not ($value -is [int])) {
                    Write-Warning "DnsHash key '$key' should be an Integer but is $($value.GetType().Name)"
                }
            }
        }
    }

    Write-Progress -Activity "DNS Hash Validation" -Status "Checking Performance settings" -PercentComplete 60
    # Verify required subkeys
    if ($DnsHash.Performance) {
        $requiredPerformanceKeys = @('BatchSize', 'MaxRunspaces', 'TimeoutMS', 'CacheExpiration', 'RetryAttempts')
        foreach ($subkey in $requiredPerformanceKeys) {
            if (-not $DnsHash.Performance.ContainsKey($subkey)) {
                Write-Warning "Performance setting '$subkey' is missing"
            }
        }
    }

    Write-Progress -Activity "DNS Hash Validation" -Status "Checking Cache components" -PercentComplete 80
    if ($DnsHash.Cache) {
        $requiredCacheKeys = @('DNSResponses', 'SCCMData', 'ValidationResults', 'DomainMapping')
        foreach ($subkey in $requiredCacheKeys) {
            if (-not $DnsHash.Cache.ContainsKey($subkey)) {
                Write-Warning "Cache component '$subkey' is missing"
            }
        }
    }

    Write-Progress -Activity "DNS Hash Validation" -Status "Validation complete" -PercentComplete 100
    return $true
}


