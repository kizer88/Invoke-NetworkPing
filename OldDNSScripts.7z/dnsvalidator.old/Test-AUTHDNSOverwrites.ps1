function Test-AUTHDNSOverwrites {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Result,
        [switch]$ForceCheck,
        [int]$StaleThresholdHours = 24
    )
    
    $Component = $MyInvocation.MyCommand
    
    try {
        # Initialize result tracking
        $validation = @{
            Check       = 'AUTHDNSOverwrites'
            Status      = 'Processing'
            Description = ''
            Details     = @{
                StaleRecords         = @()
                ReplicationConflicts = @()
                ForcedUpdates        = @()
                TrustImpact          = @{}
                CrossDomainImpact    = @{}
                OverrideHistory      = @()
                ReplicationTiming    = @{}
            }
            Timestamp   = Get-Date
        }

        # 1. Enhanced Stale Record Detection
        $localDNS = $Result.Forward
        $authDNS = @(Resolve-DnsName -Name $Result.Target `
                -Server $DnsHash.AuthDNS.Primary `
                -ErrorAction Stop | 
                Select-Object -ExpandProperty IPAddress)

        $lastUpdate = Get-DNSRecordTimestamp -Target $Result.Target
        $isStale = [math]::Abs(($lastUpdate - (Get-Date)).TotalHours) -gt $StaleThresholdHours

        if ($isStale -or (Compare-Object $localDNS.IPAddress $authDNS)) {
            $validation.Details.StaleRecords += @{
                Target     = $Result.Target
                LocalIPs   = $localDNS.IPAddress
                AuthIPs    = $authDNS
                LastUpdate = $lastUpdate
                StaleHours = [math]::Round(($lastUpdate - (Get-Date)).TotalHours, 2)
            }
        }

        # 2. Replication Conflict Detection
        $replicationStatus = Test-DNSReplicationStatus -Target $Result.Target
        if ($replicationStatus.HasConflicts) {
            $validation.Details.ReplicationConflicts += $replicationStatus.Conflicts
        }

        # 3. Forced Update Tracking
        $forcedUpdates = Get-DNSForcedUpdates -Target $Result.Target
        if ($forcedUpdates.Count -gt 0) {
            $validation.Details.ForcedUpdates += $forcedUpdates
        }

        # 4. Trust Path Validation
        $domain = Get-TargetDomain -Target $Result.Target
        $trustValidation = Test-DNSTrustPath -Domain $domain
        $validation.Details.TrustImpact[$domain] = $trustValidation

        # 5. Cross-Domain Impact Analysis
        $crossDomainImpact = Test-CrossDomainDNSImpact -Target $Result.Target -Domain $domain
        $validation.Details.CrossDomainImpact = $crossDomainImpact

        # 6. Override Notification
        $overrides = Get-DNSOverrideHistory -Target $Result.Target
        if ($overrides.Count -gt 0) {
            $validation.Details.OverrideHistory += $overrides
        }

        # 7. Replication Timing Validation
        $replicationTiming = Test-DNSReplicationTiming -Target $Result.Target
        $validation.Details.ReplicationTiming = $replicationTiming

        # Determine overall status
        $validation.Status = if ($validation.Details.StaleRecords.Count -gt 0) {
            'Stale'
        }
        elseif ($validation.Details.ReplicationConflicts.Count -gt 0) {
            'Conflict'
        }
        elseif ($validation.Details.ForcedUpdates.Count -gt 0) {
            'Modified'
        }
        else {
            'Verified'
        }

        # Generate description
        $validation.Description = switch ($validation.Status) {
            'Stale' { 
                "AUTH DNS has stale records. Last update: $($validation.Details.StaleRecords[0].LastUpdate)"
            }
            'Conflict' { 
                "Replication conflicts detected across $($validation.Details.ReplicationConflicts.Count) servers"
            }
            'Modified' {
                "Forced updates detected. Last update: $($validation.Details.ForcedUpdates[-1].Timestamp)"
            }
            'Verified' {
                "AUTH DNS records are up-to-date and consistent"
            }
            default {
                "Validation completed with status: $($validation.Status)"
            }
        }

        return $validation
    }
    catch {
        Add-DNSValidationError -Target $Result.Target `
            -ErrorRecord $_ `
            -Operation "AUTH-DNS-Check" `
            -Severity "Warning" `
            -Component $Component
        
        return @{
            Check       = 'AUTHDNSOverwrites'
            Status      = 'Error'
            Description = "Error validating AUTH DNS records: $($_.Exception.Message)"
            Details     = @{ Error = $_ }
            Timestamp   = Get-Date
        }
    }
}

# Helper Functions
function Get-DNSRecordTimestamp {
    [CmdletBinding()]
    param([string]$Target)
    
    try {
        $record = Get-WmiObject -Namespace "root\MicrosoftDNS" `
            -Class "MicrosoftDNS_AType" `
            -Filter "ContainerName='$Target'" `
            -ComputerName $DnsHash.AuthDNS.Primary
        return $record.Timestamp
    }
    catch {
        return (Get-Date).AddDays(-30)  # Default fallback for error cases
    }
}

function Test-DNSReplicationStatus {
    [CmdletBinding()]
    param([string]$Target)
    
    $conflicts = @()
    foreach ($dc in $DnsHash.AuthDNS.AllServers) {
        try {
            $records = Resolve-DnsName -Name $Target -Server $dc -ErrorAction Stop
            if ($records.Count -gt 1) {
                $conflicts += @{
                    Server    = $dc
                    Records   = $records
                    Timestamp = Get-Date
                }
            }
        }
        catch { }
    }
    
    return @{
        HasConflicts = ($conflicts.Count -gt 0)
        Conflicts    = $conflicts
    }
}

function Get-DNSForcedUpdates {
    [CmdletBinding()]
    param([string]$Target)
    
    try {
        $events = Get-WinEvent -ComputerName $DnsHash.AuthDNS.Primary `
            -FilterHashtable @{
            LogName = 'DNS Server'
            ID      = 4101  # DNS record modification event
        } `
            -MaxEvents 10 `
            -ErrorAction Stop |
            Where-Object { $_.Message -like "*$Target*" }
        
        return $events | ForEach-Object {
            @{
                EventID   = $_.ID
                Timestamp = $_.TimeCreated
                Message   = $_.Message
            }
        }
    }
    catch {
        return @()
    }
} 