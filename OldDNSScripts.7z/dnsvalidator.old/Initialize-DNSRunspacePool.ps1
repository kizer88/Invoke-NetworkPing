# Set component name for error tracking
$Component = "DNS-Runspace-Pool"

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# CRITICAL: $DnsHash IS SACRED - NEVER REMOVE OR REINITIALIZE IT
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

function Initialize-DNSRunspacePool {
    [CmdletBinding()]
    param()
    
    try {
        # Initialize synchronized hashtable if not exists
        if (-not (Get-Variable -Name DnsHash -ErrorAction SilentlyContinue)) {
            $script:DnsHash = [hashtable]::Synchronized(@{})
        }

        # Initialize required collections
        $DnsHash.ErrorLog = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
        $DnsHash.ErrorCount = 0
        $DnsHash.PingErrors = [hashtable]::Synchronized(@{})
        $DnsHash.Performance = [hashtable]::Synchronized(@{
                StartTime  = Get-Date
                Metrics    = @{}
                Thresholds = @{
                    Warning  = 500  # ms
                    Critical = 2000 # ms
                }
            })
        $DnsHash.ValidationPriority = [hashtable]::Synchronized(@{
                High   = [System.Collections.ArrayList]::new()
                Normal = [System.Collections.ArrayList]::new()
                Low    = [System.Collections.ArrayList]::new()
            })
        $DnsHash.Cache = [hashtable]::Synchronized(@{
                DNSRecords = @{}
                LastUpdate = Get-Date
                TTL        = 3600  # 1 hour default
            })
        $DnsHash.RunspaceConfig = @{
            MaxThreads     = 10
            IdleTimeout    = 300  # 5 minutes
            UseCompression = $true
            Priority       = "Normal"
        }

        # Initialize synchronized hashtable
        $script:DnsHash = [hashtable]::Synchronized(@{
                AuthDNS           = @{
                    Primary    = '15.97.197.92'
                    Secondary  = '15.97.196.29'
                    AllServers = @('15.97.197.92', '15.97.196.29')
                }
                TrustMap          = @{
                    'AUTH' = @{
                        DNSServers = @('15.97.197.92', '15.97.196.29')
                        TrustsDown = @('CVS', 'IM1')
                    }
                }
                TrustChain        = @{
                    Initialized = $false
                    LastCheck   = $null
                    Status      = 'NotInitialized'
                }
                ValidationResults = @{}
                RunspacePool      = $null
                MaxThreads        = 0
                ActiveJobs        = @{}
            })

        # Initialize runspace pool
        $maxThreads = Get-DynamicPoolSize
        $DnsHash.MaxThreads = $maxThreads
        
        $sessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
        $runspacePool = [runspacefactory]::CreateRunspacePool(1, $maxThreads, $sessionState, $Host)
        $runspacePool.Open()
        
        $DnsHash.RunspacePool = $runspacePool

        # Validate AUTH DNS connectivity
        $authDnsStatus = Test-AuthDNSConnectivity
        if (-not $authDnsStatus.IsHealthy) {
            throw "AUTH DNS validation failed: $($authDnsStatus.Error)"
        }

        Write-Verbose "DNS Runspace Pool initialized with $maxThreads threads"
        return $true
    }
    catch {
        Write-Error "Failed to initialize DNS Runspace Pool: $_"
        return $false
    }
}

function Get-DynamicPoolSize {
    [CmdletBinding()]
    param()
    
    try {
        $processors = (Get-WmiObject -Class Win32_Processor).NumberOfLogicalProcessors
        if ($processors -gt 1) {
            return [Math]::Min(($processors * 3), 50)  # Cap at 50 threads
        }
        return 10  # Default for single processor systems
    }
    catch {
        return 10  # Fallback default
    }
}

function Test-AuthDNSConnectivity {
    [CmdletBinding()]
    param()
    
    try {
        $status = @{
            IsHealthy = $true
            Error     = $null
        }

        foreach ($server in $DnsHash.AuthDNS.AllServers) {
            if (-not (Test-Connection -ComputerName $server -Count 1 -Quiet)) {
                $status.IsHealthy = $false
                $status.Error = "Cannot reach AUTH DNS server: $server"
                break
            }
        }

        return $status
    }
    catch {
        return @{
            IsHealthy = $false
            Error     = $_.Exception.Message
        }
    }
}


