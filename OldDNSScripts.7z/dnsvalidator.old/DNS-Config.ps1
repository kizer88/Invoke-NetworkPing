# Set component name for error tracking
$Component = "DNS-Configuration"

# Initialize DnsHash if not exists
if (-not (Get-Variable -Name DnsHash -ErrorAction SilentlyContinue)) {
    $global:DnsHash = @{}
}

# AUTH DNS Server Configuration
$DnsHash.AuthDNS = @{
    Primary             = '15.97.197.92'
    Secondary           = '15.97.196.29'
    ValidationPriority  = 1
    HealthCheckInterval = 300  # 5 minutes
    MaxResponseTime     = 2000     # milliseconds
}

# Trust Chain Configuration
$DnsHash.TrustMap = @{
    'AUTH' = @{
        'DNSServers'         = @($DnsHash.AuthDNS.Primary, $DnsHash.AuthDNS.Secondary)
        'TrustsDown'         = @('CVS', 'IM1')
        'TrustedBy'          = @()
        'TrustType'          = 'Root'
        'ValidationPriority' = 1
        'HealthCheck'        = @{
            'Interval'   = 300
            'LastCheck'  = $null
            'Status'     = 'Unknown'
            'Thresholds' = @{
                'ResponseTime' = 2000
                'FailureCount' = 3
            }
        }
    }
    'CVS'  = @{
        'DNSServers'         = @('corsi-cvsdc02.CVS.RD.ADAPPS.HP.COM', 'corsi-cvsdc03.CVS.RD.ADAPPS.HP.COM')
        'TrustsUp'           = @('AUTH')
        'TrustedBy'          = @('AUTH')
        'TrustType'          = 'Bidirectional'
        'ValidationPriority' = 2
        'HealthCheck'        = @{
            'Interval'   = 300
            'LastCheck'  = $null
            'Status'     = 'Unknown'
            'Thresholds' = @{
                'ResponseTime' = 2000
                'FailureCount' = 3
            }
        }
    }
    'IM1'  = @{
        'DNSServers'         = @('im1dc01.IM1.MFG.HPICORP.NET', 'im1dc02.IM1.MFG.HPICORP.NET')
        'TrustsUp'           = @('AUTH')
        'TrustedBy'          = @('AUTH')
        'TrustType'          = 'Bidirectional'
        'ValidationPriority' = 2
        'HealthCheck'        = @{
            'Interval'   = 300
            'LastCheck'  = $null
            'Status'     = 'Unknown'
            'Thresholds' = @{
                'ResponseTime' = 2000
                'FailureCount' = 3
            }
        }
    }
}

# Replication and Resolution Parameters
$DnsHash.ValidationParameters = @{
    ReplicationThresholds = @{
        Warning  = 900    # 15 minutes
        Critical = 3600  # 1 hour
        MaxAge   = 86400   # 24 hours
    }
    ResolutionTimeouts    = @{
        LocalDomain  = 5     # seconds
        CrossDomain  = 10    # seconds
        AuthDNS      = 8        # seconds
        FailureRetry = 2    # retry count
    }
    ValidationChain       = @{
        Priority       = @{
            LocalDNS    = 1    # Fastest, most relevant
            SCCM        = 2        # Cached data
            CrossDomain = 3  # Only if needed
            Historical  = 4   # Background task
        }
        RequiredChecks = @(
            'LocalDNS',
            'AuthDNS',
            'TrustChain'
        )
    }
    TrustValidation       = @{
        CheckInterval     = 300  # 5 minutes
        RetryCount        = 3
        TimeoutSeconds    = 30
        RequiredServers   = @(
            $DnsHash.AuthDNS.Primary,
            $DnsHash.AuthDNS.Secondary
        )
        ValidationMethods = @(
            'DNSResolution',
            'TrustEnum',
            'DCLocator'
        )
    }
}

# Initialize Collections as Synchronized ArrayLists
$DnsHash.Verified = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.Orphaned = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.Stale = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.Mismatched = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.ErrorLog = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.ValidationHistory = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
$DnsHash.ErrorCount = 0
$DnsHash.PingErrors = [hashtable]::Synchronized(@{})

# Performance Configuration
$DnsHash.Performance = @{
    MaxRunspaces   = 20
    BatchSize      = 50
    ThrottleLimit  = 10
    TimeoutSeconds = 30
}

# Load required components
if (-not(Get-Command Query-SCCMServers -ErrorAction SilentlyContinue)) {
    . "$PSScriptRoot\Query-SCCMServers.ps1"
}

try {
    Query-SccmServers
    # Initialize Runspace Pool
    Initialize-DNSRunspacePool

    Write-Verbose "DNS Configuration loaded successfully"
}
catch {
    Add-DNSValidationError -Target "Configuration" -ErrorRecord $_ -Operation "Initialize-Config" -Severity "Critical" -Component $Component
    throw
}