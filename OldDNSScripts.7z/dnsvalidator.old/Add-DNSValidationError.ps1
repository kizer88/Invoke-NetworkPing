function Add-DNSValidationError {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$Target,
        
        [Parameter(Mandatory)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord,
        
        [Parameter(Mandatory)]
        [string]$Operation,
        
        [Parameter(Mandatory)]
        [string]$Severity,
        
        [Parameter(Mandatory)]
        [string]$Component,

        [Parameter()]
        [ValidateSet('AUTH', 'CVS', 'IM1')]
        [string]$TrustContext,

        [Parameter()]
        [hashtable]$DomainRelationship = @{
            SourceDomain = ''
            TargetDomain = ''
            TrustType    = ''  # Bidirectional, Inbound, Outbound
            TrustStatus  = ''  # Active, Broken, Degraded
        },

        [Parameter()]
        [hashtable]$ReplicationStatus = @{
            LastReplication  = $null
            ReplicationDelay = $null
            PropagationState = 'Unknown' # Complete, Partial, Failed
        }
    )
    
    # Initialize DnsHash if not exists
    if (-not (Get-Variable -Name DnsHash -ErrorAction SilentlyContinue)) {
        $script:DnsHash = [hashtable]::Synchronized(@{})
    }

    # Initialize error tracking if not exists
    if (-not $DnsHash.ContainsKey('ErrorLog')) {
        $DnsHash.ErrorLog = [System.Collections.ArrayList]::Synchronized([System.Collections.ArrayList]::new())
    }
    if (-not $DnsHash.ContainsKey('ErrorCount')) {
        $DnsHash.ErrorCount = 0
    }
    if (-not $DnsHash.ContainsKey('PingErrors')) {
        $DnsHash.PingErrors = [hashtable]::Synchronized(@{})
    }

    # Calculate trust impact severity
    $trustImpactSeverity = switch ($TrustContext) {
        'AUTH' { 'Critical' } # AUTH failures affect all domains
        'CVS' { if ($DomainRelationship.TrustStatus -eq 'Broken') { 'High' } else { 'Medium' } }
        'IM1' { if ($DomainRelationship.TrustStatus -eq 'Broken') { 'High' } else { 'Medium' } }
        default { $Severity }
    }

    # Calculate replication delay if timestamps available
    $replicationDelay = if ($ReplicationStatus.LastReplication) {
        (Get-Date) - $ReplicationStatus.LastReplication
    }
    else { $null }
    
    # Build enhanced error object
    $errorObject = @{
        ID                = [System.Guid]::NewGuid().ToString()
        Timestamp         = Get-Date
        Component         = $Component
        Line              = $MyInvocation.ScriptLineNumber
        Target            = $Target
        Operation         = $Operation
        Message           = $ErrorRecord.Exception.Message
        FullError         = $ErrorRecord.Exception.ToString()
        Severity          = $trustImpactSeverity
        ScriptName        = $MyInvocation.ScriptName
        CallStack         = Get-PSCallStack | Select-Object -First 3 | ConvertTo-Json
        ErrorCode         = $ErrorRecord.FullyQualifiedErrorId

        # Enhanced trust and domain tracking
        TrustContext      = $TrustContext
        TrustPathStatus   = @{
            Context      = $TrustContext
            Relationship = $DomainRelationship
            Impact       = $trustImpactSeverity
        }
        AuthDNSValidation = @{
            Status         = if ($TrustContext -eq 'AUTH') { 'Failed' } else { 'Unknown' }
            LastValidation = Get-Date
            AuthServers    = $DnsHash.AuthDNS
        }
        CrossDomainImpact = @{
            AffectedDomains   = @()
            PropagationStatus = $ReplicationStatus.PropagationState
            ReplicationDelay  = $replicationDelay
            TrustChainBreak   = $DomainRelationship.TrustStatus -eq 'Broken'
        }
        ReplicationStatus = $ReplicationStatus
    }

    # Determine affected domains based on trust context
    $errorObject.CrossDomainImpact.AffectedDomains = switch ($TrustContext) {
        'AUTH' { @('CVS', 'IM1') }
        'CVS' { @('CVS', $(if ($DomainRelationship.TrustStatus -eq 'Broken') { 'AUTH' })) }
        'IM1' { @('IM1', $(if ($DomainRelationship.TrustStatus -eq 'Broken') { 'AUTH' })) }
        default { @() }
    }

    # Track in PingErrors for operational monitoring
    if (-not $DnsHash.PingErrors.ContainsKey($Target)) {
        $DnsHash.PingErrors[$Target] = @{}
    }
    $DnsHash.PingErrors[$Target] = @{
        Operation         = $Operation
        Result            = $trustImpactSeverity
        TrustContext      = $TrustContext
        ReplicationStatus = $ReplicationStatus.PropagationState
        ErrorCode         = $errorObject.ErrorCode
    }
    
    # Add to ErrorLog with correlation
    try {
        # Check for related errors in the same trust context
        $relatedErrors = $DnsHash.ErrorLog | Where-Object { 
            $_.TrustContext -eq $TrustContext -and 
            $_.Timestamp -gt (Get-Date).AddMinutes(-15) 
        }
        
        if ($relatedErrors) {
            $errorObject.CorrelatedErrors = $relatedErrors.ID
        }

        [void]$DnsHash.ErrorLog.Add($errorObject)
        $DnsHash.ErrorCount++
        
        Write-Verbose "Added error for Target: $Target in $TrustContext context. Total Errors: $($DnsHash.ErrorCount)"
        Write-Verbose "Trust Impact: $trustImpactSeverity, Replication Delay: $($replicationDelay.TotalMinutes) minutes"
    }
    catch {
        Write-Error "Failed to add error to ErrorLog: $_"
    }
    
    return $errorObject
}
