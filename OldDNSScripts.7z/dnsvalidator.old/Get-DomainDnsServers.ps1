function Get-DomainDnsServers {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Domain,
        [switch]$ForceRefresh,
        [switch]$IncludeHealth
    )

    $Component = $MyInvocation.MyCommand
    
    # Initialize DNS server cache if needed
    if (-not $DnsHash.Cache.DnsServers) {
        $DnsHash.Cache.DnsServers = [hashtable]::Synchronized(@{})
    }

    # Initialize health tracking if needed
    if (-not $DnsHash.ServerHealth) {
        $DnsHash.ServerHealth = [hashtable]::Synchronized(@{})
    }

    try {
        # Check cache first unless force refresh
        $cacheKey = "${Domain}_DNSServers"
        $cacheValid = $DnsHash.Cache.DnsServers[$cacheKey] -and 
                     ((Get-Date) - $DnsHash.Cache.DnsServers[$cacheKey].Timestamp).TotalMinutes -lt 15

        if (-not $ForceRefresh -and $cacheValid) {
            Write-Verbose "Using cached DNS servers for $Domain"
            return $DnsHash.Cache.DnsServers[$cacheKey].Servers
        }

        # Get domain-specific DNS servers with health check
        $dnsServers = @()
        $healthResults = @{}

        # AUTH DNS priority logic
        if ($Domain -eq 'AUTH' -or $DnsHash.TrustMap[$Domain].TrustsUp -contains 'AUTH') {
            $authServers = @{
                Primary   = $DnsHash.AuthDNS.Primary
                Secondary = $DnsHash.AuthDNS.Secondary
            }

            foreach ($server in $authServers.Values) {
                $health = Test-DnsServerHealth -Server $server
                if ($health.Status -eq 'Healthy') {
                    $dnsServers += $server
                    $healthResults[$server] = $health
                }
            }
        }

        # Domain-specific DNS servers
        $domainServers = $DnsHash.TrustMap[$Domain].DNSServers
        foreach ($server in $domainServers) {
            $health = Test-DnsServerHealth -Server $server
            if ($health.Status -eq 'Healthy') {
                $dnsServers += $server
                $healthResults[$server] = $health
            }
        }

        # Implement fallback logic if no healthy servers found
        if (-not $dnsServers) {
            Write-Verbose "No healthy DNS servers found, implementing fallback logic"
            # Try AUTH DNS as fallback
            if ($Domain -ne 'AUTH') {
                $authHealth = Test-DnsServerHealth -Server $DnsHash.AuthDNS.Primary
                if ($authHealth.Status -eq 'Healthy') {
                    $dnsServers += $DnsHash.AuthDNS.Primary
                    $healthResults[$DnsHash.AuthDNS.Primary] = $authHealth
                }
            }
        }

        # Update cache with server list and health data
        $DnsHash.Cache.DnsServers[$cacheKey] = @{
            Servers   = $dnsServers
            Health    = $healthResults
            Timestamp = Get-Date
            TrustPath = $DnsHash.TrustMap[$Domain].TrustsUp
        }

        # Update global health tracking
        foreach ($server in $healthResults.Keys) {
            $DnsHash.ServerHealth[$server] = $healthResults[$server]
        }

        if ($IncludeHealth) {
            return @{
                Servers   = $dnsServers
                Health    = $healthResults
                TrustPath = $DnsHash.TrustMap[$Domain].TrustsUp
            }
        }

        return $dnsServers
    }
    catch {
        Add-DNSValidationError -Target $Domain -ErrorRecord $_ -Operation "Get-DomainDNSServers" -Severity "Critical" -Component $Component
        throw
    }
}

function Test-DnsServerHealth {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Server
    )

    try {
        $startTime = Get-Date
        $result = @{
            Server            = $Server
            Status            = 'Unknown'
            ResponseTime      = $null
            LastCheck         = Get-Date
            ReplicationStatus = $null
            FailureCount      = 0
        }

        # Test basic connectivity
        $testResult = Test-Connection -ComputerName $Server -Count 1 -ErrorAction Stop
        $result.ResponseTime = ((Get-Date) - $startTime).TotalMilliseconds

        # Check response time against thresholds
        if ($result.ResponseTime -gt $DnsHash.TrustMap['AUTH'].HealthCheck.Thresholds.ResponseTime) {
            $result.Status = 'Degraded'
            return $result
        }

        # Test DNS resolution
        $dnsTest = Resolve-DnsName -Name $Server -Server $Server -ErrorAction Stop
        if (-not $dnsTest) {
            $result.Status = 'Failed'
            return $result
        }

        # Check replication status for domain controllers
        if ($Server -match '\.(?:CVS|IM1)\.') {
            $replicationStatus = Get-ReplicationStatus -Server $Server
            $result.ReplicationStatus = $replicationStatus

            if ($replicationStatus.Status -ne 'Current') {
                $result.Status = 'Degraded'
                return $result
            }
        }

        $result.Status = 'Healthy'
        return $result
    }
    catch {
        $result.Status = 'Failed'
        $result.FailureCount++
        return $result
    }
}

function Get-ReplicationStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Server
    )

    try {
        # Mock replication check - replace with actual replication check logic
        return @{
            Status           = 'Current'
            LastReplication  = Get-Date
            ReplicationDelay = 0
        }
    }
    catch {
        return @{
            Status           = 'Unknown'
            LastReplication  = $null
            ReplicationDelay = $null
        }
    }
}

# Priority Constants
$DnsResolutionPriority = @{
    'LocalDNS'    = 1    # Fastest, most relevant
    'SCCM'        = 2        # Cached data
    'CrossDomain' = 3 # Only if needed
    'Historical'  = 4  # Background task
}
