function Invoke-DNSResolutionWorker {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Target,
        [Parameter(Mandatory)]
        [string]$Domain,
        [System.Management.Automation.Runspaces.RunspacePool]$RunspacePool,
        [switch]$ForceRefresh,
        [switch]$ValidateTrust
    )
    
    $Component = "Invoke-DNSResolutionWorker"
    
    try {
        # Initialize result object
        $result = @{
            Target          = $Target
            Domain          = $Domain
            Resolution      = $null
            TrustPath       = @()
            ValidationChain = [System.Collections.ArrayList]::new()
            Timestamp       = Get-Date
            Status          = 'Processing'
        }

        # 1. Trust Chain Validation
        $trustValidation = Test-ResolutionTrustChain -Domain $Domain
        [void]$result.ValidationChain.Add($trustValidation)

        if (-not $trustValidation.IsValid) {
            Write-Verbose "Trust chain validation failed for $Target in domain $Domain"
            return Initialize-FallbackResolution -Target $Target -Result $result
        }

        # 2. Get Domain Controllers with Health Check
        $dcSelection = Select-HealthyDomainController -Domain $Domain
        if (-not $dcSelection.Success) {
            Write-Verbose "No healthy DC found for $Domain, attempting AUTH fallback"
            return Initialize-AuthFallback -Target $Target -Result $result
        }

        # 3. Primary Resolution Attempt
        $primaryResolution = Invoke-PrimaryResolution -Target $Target `
            -DomainController $dcSelection.Server `
            -Result $result

        if ($primaryResolution.Success) {
            $result.Resolution = $primaryResolution.Resolution
            $result.Status = 'Resolved'
        }
        else {
            # 4. Cross-Domain Resolution
            $crossDomainResult = Invoke-CrossDomainResolution -Target $Target `
                -OriginalDomain $Domain `
                -Result $result

            if ($crossDomainResult.Success) {
                $result.Resolution = $crossDomainResult.Resolution
                $result.Status = 'CrossDomainResolved'
            }
            else {
                # 5. AUTH Fallback
                $authResult = Invoke-AuthResolution -Target $Target -Result $result
                if ($authResult.Success) {
                    $result.Resolution = $authResult.Resolution
                    $result.Status = 'AuthResolved'
                }
                else {
                    $result.Status = 'Failed'
                }
            }
        }

        # 6. Validate Against AUTH
        if ($result.Status -match 'Resolved') {
            $authValidation = Compare-AuthResolution -Resolution $result.Resolution `
                -Target $Target
            [void]$result.ValidationChain.Add($authValidation)
        }

        return $result
    }
    catch {
        Add-DNSValidationError -Target $Target `
            -ErrorRecord $_ `
            -Operation "DNSResolution" `
            -Severity "Error" `
            -Component $Component `
            -TrustContext $Domain
        return @{
            Target    = $Target
            Domain    = $Domain
            Status    = 'Error'
            Error     = $_
            Timestamp = Get-Date
        }
    }
}

function Test-ResolutionTrustChain {
    [CmdletBinding()]
    param([string]$Domain)
    
    try {
        $trustPath = switch ($Domain) {
            'AUTH' { @('AUTH') }
            'CVS' { @('CVS', 'AUTH') }
            'IM1' { @('IM1', 'AUTH') }
        }

        $validation = @{
            Type    = 'TrustChain'
            Path    = $trustPath
            IsValid = $true
            Details = @{}
        }

        foreach ($hop in $trustPath) {
            if ($hop -ne 'AUTH') {
                $trustStatus = $DnsHash.TrustMap[$hop].TrustsUp -contains 'AUTH'
                $validation.Details[$hop] = @{
                    Status    = if ($trustStatus) { 'Valid' } else { 'Broken' }
                    Timestamp = Get-Date
                }
                $validation.IsValid = $validation.IsValid -and $trustStatus
            }
        }

        return $validation
    }
    catch {
        return @{
            Type      = 'TrustChain'
            IsValid   = $false
            Error     = $_
            Timestamp = Get-Date
        }
    }
}

function Select-HealthyDomainController {
    [CmdletBinding()]
    param([string]$Domain)
    
    try {
        $dcs = $DnsHash.TrustMap[$Domain].DNSServers
        foreach ($dc in $dcs) {
            $health = Test-DnsServerHealth -Server $dc
            if ($health.Status -eq 'Healthy') {
                return @{
                    Success = $true
                    Server  = $dc
                    Health  = $health
                }
            }
        }
        return @{ Success = $false }
    }
    catch {
        return @{ Success = $false; Error = $_ }
    }
}

function Invoke-PrimaryResolution {
    [CmdletBinding()]
    param(
        [string]$Target,
        [string]$DomainController,
        [hashtable]$Result
    )
    
    try {
        $resolution = Resolve-DnsName -Name $Target `
            -Server $DomainController `
            -ErrorAction Stop

        # Check replication status
        $replStatus = Get-ReplicationStatus -Server $DomainController
        [void]$Result.ValidationChain.Add(@{
                Type      = 'Replication'
                Status    = $replStatus.Status
                Delay     = $replStatus.Delay
                Timestamp = Get-Date
            })

        return @{
            Success           = $true
            Resolution        = $resolution
            ReplicationStatus = $replStatus
        }
    }
    catch {
        return @{ Success = $false; Error = $_ }
    }
}

function Invoke-CrossDomainResolution {
    [CmdletBinding()]
    param(
        [string]$Target,
        [string]$OriginalDomain,
        [hashtable]$Result
    )
    
    try {
        $otherDomains = @('CVS', 'IM1', 'AUTH') | Where-Object { $_ -ne $OriginalDomain }
        
        foreach ($domain in $otherDomains) {
            $dc = Select-HealthyDomainController -Domain $domain
            if ($dc.Success) {
                $resolution = Resolve-DnsName -Name $Target `
                    -Server $dc.Server `
                    -ErrorAction Stop
                if ($resolution) {
                    [void]$Result.ValidationChain.Add(@{
                            Type      = 'CrossDomain'
                            Domain    = $domain
                            Server    = $dc.Server
                            Timestamp = Get-Date
                        })
                    return @{
                        Success         = $true
                        Resolution      = $resolution
                        ResolvingDomain = $domain
                    }
                }
            }
        }
        return @{ Success = $false }
    }
    catch {
        return @{ Success = $false; Error = $_ }
    }
}

function Invoke-AuthResolution {
    [CmdletBinding()]
    param(
        [string]$Target,
        [hashtable]$Result
    )
    
    try {
        foreach ($authServer in @($DnsHash.AuthDNS.Primary, $DnsHash.AuthDNS.Secondary)) {
            $resolution = Resolve-DnsName -Name $Target `
                -Server $authServer `
                -ErrorAction Stop
            if ($resolution) {
                [void]$Result.ValidationChain.Add(@{
                        Type      = 'AuthFallback'
                        Server    = $authServer
                        Timestamp = Get-Date
                    })
                return @{
                    Success    = $true
                    Resolution = $resolution
                    AuthServer = $authServer
                }
            }
        }
        return @{ Success = $false }
    }
    catch {
        return @{ Success = $false; Error = $_ }
    }
}

function Compare-AuthResolution {
    [CmdletBinding()]
    param(
        $Resolution,
        [string]$Target
    )
    
    try {
        $authResolution = Resolve-DnsName -Name $Target `
            -Server $DnsHash.AuthDNS.Primary `
            -ErrorAction Stop

        return @{
            Type      = 'AuthValidation'
            Matches   = ($Resolution.IPAddress -eq $authResolution.IPAddress)
            AuthIP    = $authResolution.IPAddress
            LocalIP   = $Resolution.IPAddress
            Timestamp = Get-Date
        }
    }
    catch {
        return @{
            Type      = 'AuthValidation'
            Matches   = $false
            Error     = $_
            Timestamp = Get-Date
        }
    }
}