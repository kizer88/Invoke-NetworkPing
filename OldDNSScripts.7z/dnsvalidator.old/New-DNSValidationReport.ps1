function New-DNSValidationReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object]$ValidationResults,
        [string]$ReportTitle = "DNS Validation Status Report",
        [switch]$IncludeTrustChain,
        [switch]$IncludeReplication
    )
    
    $Component = $MyInvocation.MyCommand

    try {
        # Enhanced CSS with trust chain visualization support
        $DnsHash.css = @"
        <style>
            body { font-family: 'Segoe UI', Tahoma, sans-serif; margin: 20px; background: #f8f9fa; }
            .header { background: #0078D4; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
            .summary { margin: 20px 0; padding: 15px; background: white; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .trust-chain { margin: 15px 0; padding: 15px; background: white; border-radius: 5px; }
            .trust-path { display: flex; align-items: center; margin: 10px 0; }
            .trust-node { background: #0078D4; color: white; padding: 8px 15px; border-radius: 3px; margin: 0 5px; }
            .trust-arrow { color: #666; font-size: 20px; margin: 0 10px; }
            .status-success { background: #28a745; color: white; padding: 5px 10px; border-radius: 3px; }
            .status-error { background: #dc3545; color: white; padding: 5px 10px; border-radius: 3px; }
            .status-warning { background: #ffc107; padding: 5px 10px; border-radius: 3px; }
            .metric-card { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .validation-chain { margin: 15px 0; padding: 15px; background: white; border-radius: 5px; }
            .replication-status { margin: 10px 0; padding: 10px; background: #f8f9fa; border-left: 4px solid #0078D4; }
            .domain-metrics { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px; margin: 15px 0; }
            .chart-container { height: 300px; margin: 20px 0; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; background: white; }
            th { background: #0078D4; color: white; padding: 10px; text-align: left; }
            td { padding: 8px; border-bottom: 1px solid #dee2e6; }
            .progress-bar { height: 20px; background: #e9ecef; border-radius: 10px; overflow: hidden; }
            .progress-fill { height: 100%; background: #0078D4; transition: width 0.3s ease; }
        </style>
"@

        # 1. Trust Chain Visualization
        $trustChainHtml = if ($IncludeTrustChain) {
            $trustChains = Get-TrustChainVisualization -ValidationResults $ValidationResults
            @"
            <div class="trust-chain">
                <h2>Trust Chain Status</h2>
                $trustChains
            </div>
"@
        }

        # 2. AUTH DNS Impact Analysis
        $authImpactHtml = Get-AuthDNSImpactAnalysis -ValidationResults $ValidationResults

        # 3. Domain Relationship Status
        $domainRelationshipHtml = Get-DomainRelationshipStatus -ValidationResults $ValidationResults

        # 4. Replication Delay Reporting
        $replicationHtml = if ($IncludeReplication) {
            Get-ReplicationDelayReport -ValidationResults $ValidationResults
        }

        # 5. Cross-Domain Resolution Metrics
        $crossDomainMetricsHtml = Get-CrossDomainMetrics -ValidationResults $ValidationResults

        # 6. Trust Path Validation Results
        $trustPathResultsHtml = Get-TrustPathValidationResults -ValidationResults $ValidationResults

        # 7. Validation Chain Success Rates
        $validationChainMetricsHtml = Get-ValidationChainMetrics -ValidationResults $ValidationResults

        # Combine all sections into final report
        $DnsHash.html = @"
        <!DOCTYPE html>
        <html>
        <head>
            <title>$ReportTitle</title>
            $($DnsHash.css)
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        </head>
        <body>
            <div class="header">
                <h1>$ReportTitle</h1>
                <p>Generated on $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>
            </div>

            <div class="summary">
                <h2>Executive Summary</h2>
                <div class="domain-metrics">
                    $($validationChainMetricsHtml)
                </div>
            </div>

            $trustChainHtml
            $authImpactHtml
            $domainRelationshipHtml
            $replicationHtml
            $crossDomainMetricsHtml
            $trustPathResultsHtml

            <script>
                // Chart initialization code
                function initializeCharts() {
                    // Add any necessary chart initialization
                }
                document.addEventListener('DOMContentLoaded', initializeCharts);
            </script>
        </body>
        </html>
"@

        return $DnsHash.html
    }
    catch {
        Add-DNSValidationError -Target "ReportGeneration" -ErrorRecord $_ -Operation "Generate-Report" -Severity "Critical" -Component $Component
        throw
    }
}

function Get-TrustChainVisualization {
    param($ValidationResults)
    
    $trustChains = foreach ($domain in @('CVS', 'IM1')) {
        $trustStatus = $ValidationResults.TrustStatus[$domain]
        $statusClass = if ($trustStatus.IsValid) { 'status-success' } else { 'status-error' }
        
        @"
        <div class="trust-path">
            <span class="trust-node">$domain</span>
            <span class="trust-arrow">→</span>
            <span class="trust-node">AUTH</span>
            <span class="$statusClass">$($trustStatus.Status)</span>
        </div>
"@
    }
    
    return $trustChains -join "`n"
}

function Get-AuthDNSImpactAnalysis {
    param($ValidationResults)
    
    $authMetrics = @{
        TotalQueries = 0
        Overrides    = 0
        Conflicts    = 0
    }

    foreach ($result in $ValidationResults.Results.Values) {
        if ($result.AuthValidation) {
            $authMetrics.TotalQueries++
            if ($result.AuthValidation.HasOverride) {
                $authMetrics.Overrides++
            }
            if ($result.AuthValidation.HasConflict) {
                $authMetrics.Conflicts++
            }
        }
    }

    return @"
    <div class="metric-card">
        <h2>AUTH DNS Impact Analysis</h2>
        <table>
            <tr><th>Metric</th><th>Value</th></tr>
            <tr><td>Total AUTH Queries</td><td>$($authMetrics.TotalQueries)</td></tr>
            <tr><td>AUTH Overrides</td><td>$($authMetrics.Overrides)</td></tr>
            <tr><td>Resolution Conflicts</td><td>$($authMetrics.Conflicts)</td></tr>
        </table>
    </div>
"@
}

function Get-DomainRelationshipStatus {
    param($ValidationResults)
    
    $relationships = foreach ($domain in @('CVS', 'IM1')) {
        $status = $ValidationResults.DomainRelationships[$domain]
        $statusClass = switch ($status.Health) {
            'Healthy' { 'status-success' }
            'Warning' { 'status-warning' }
            default { 'status-error' }
        }
        
        @"
        <tr>
            <td>$domain → AUTH</td>
            <td class="$statusClass">$($status.Health)</td>
            <td>$($status.LastValidated)</td>
            <td>$($status.TrustType)</td>
        </tr>
"@
    }

    return @"
    <div class="metric-card">
        <h2>Domain Relationship Status</h2>
        <table>
            <tr>
                <th>Relationship</th>
                <th>Status</th>
                <th>Last Validated</th>
                <th>Trust Type</th>
            </tr>
            $relationships
        </table>
    </div>
"@
}

function Get-ReplicationDelayReport {
    param($ValidationResults)
    
    $replicationData = foreach ($domain in @('CVS', 'IM1', 'AUTH')) {
        $replStatus = $ValidationResults.ReplicationStatus[$domain]
        $statusClass = switch ($replStatus.State) {
            'Current' { 'status-success' }
            'Warning' { 'status-warning' }
            default { 'status-error' }
        }
        
        @"
        <div class="replication-status">
            <h3>$domain</h3>
            <p>Status: <span class="$statusClass">$($replStatus.State)</span></p>
            <p>Last Sync: $($replStatus.LastSync)</p>
            <p>Delay: $($replStatus.Delay) minutes</p>
        </div>
"@
    }

    return @"
    <div class="metric-card">
        <h2>Replication Status</h2>
        $replicationData
    </div>
"@
}

function Get-CrossDomainMetrics {
    param($ValidationResults)
    
    $metrics = @{
        TotalCrossResolutions = 0
        SuccessRate           = 0
        Conflicts             = 0
    }

    foreach ($result in $ValidationResults.Results.Values) {
        if ($result.CrossDomainResolutions) {
            $metrics.TotalCrossResolutions++
            if ($result.CrossDomainResolutions.Success) {
                $metrics.SuccessRate++
            }
            if ($result.CrossDomainResolutions.Conflicts) {
                $metrics.Conflicts++
            }
        }
    }

    $successRate = if ($metrics.TotalCrossResolutions -gt 0) {
        [math]::Round(($metrics.SuccessRate / $metrics.TotalCrossResolutions) * 100, 2)
    }
    else { 0 }

    return @"
    <div class="metric-card">
        <h2>Cross-Domain Resolution Metrics</h2>
        <div class="progress-bar">
            <div class="progress-fill" style="width: $($successRate)%"></div>
        </div>
        <table>
            <tr><td>Success Rate</td><td>$successRate%</td></tr>
            <tr><td>Total Cross-Domain Resolutions</td><td>$($metrics.TotalCrossResolutions)</td></tr>
            <tr><td>Resolution Conflicts</td><td>$($metrics.Conflicts)</td></tr>
        </table>
    </div>
"@
}

function Get-TrustPathValidationResults {
    param($ValidationResults)
    
    $trustResults = foreach ($domain in @('CVS', 'IM1')) {
        $validation = $ValidationResults.TrustValidation[$domain]
        $statusClass = if ($validation.IsValid) { 'status-success' } else { 'status-error' }
        
        @"
        <tr>
            <td>$domain</td>
            <td class="$statusClass">$($validation.Status)</td>
            <td>$($validation.Path -join ' -> ')</td>
            <td>$($validation.LastValidated)</td>
        </tr>
"@
    }

    return @"
    <div class="metric-card">
        <h2>Trust Path Validation Results</h2>
        <table>
            <tr>
                <th>Domain</th>
                <th>Status</th>
                <th>Trust Path</th>
                <th>Last Validated</th>
            </tr>
            $trustResults
        </table>
    </div>
"@
}

function Get-ValidationChainMetrics {
    param($ValidationResults)
    
    $metrics = @{
        TotalValidations      = 0
        SuccessfulValidations = 0
        FailedValidations     = 0
        ValidationRate        = 0
    }

    foreach ($result in $ValidationResults.Results.Values) {
        foreach ($validation in $result.ValidationChain) {
            $metrics.TotalValidations++
            if ($validation.Status -eq 'Passed') {
                $metrics.SuccessfulValidations++
            }
            else {
                $metrics.FailedValidations++
            }
        }
    }

    $metrics.ValidationRate = if ($metrics.TotalValidations -gt 0) {
        [math]::Round(($metrics.SuccessfulValidations / $metrics.TotalValidations) * 100, 2)
    }
    else { 0 }

    return @"
    <div class="metric-card">
        <h2>Validation Chain Success Rates</h2>
        <div class="progress-bar">
            <div class="progress-fill" style="width: $($metrics.ValidationRate)%"></div>
        </div>
        <table>
            <tr><td>Overall Success Rate</td><td>$($metrics.ValidationRate)%</td></tr>
            <tr><td>Total Validations</td><td>$($metrics.TotalValidations)</td></tr>
            <tr><td>Successful Validations</td><td>$($metrics.SuccessfulValidations)</td></tr>
            <tr><td>Failed Validations</td><td>$($metrics.FailedValidations)</td></tr>
        </table>
    </div>
"@
}
