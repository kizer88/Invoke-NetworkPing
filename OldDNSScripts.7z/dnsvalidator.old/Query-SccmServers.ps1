function Query-SCCMServers {
    [CmdletBinding()]
    param()
    
    Write-Verbose "Starting SCCM query process"
    
    # Initialize or use cache
    if ($null -eq $DnsHash.Cache.SCCMData) {
        $DnsHash.Cache.SCCMData = @{}
    }

    # Query IM1 Domain
    try {
        Write-Progress -Activity "SCCM Query" -Status "Querying IM1 SCCM" -PercentComplete 25
        
        $im1Query = @{
            Query        = "Select Name, IPAddresses, ResourceID, FullDomainName from SMS_R_System"
            Namespace    = "root\sms\site_USM"
            ComputerName = "MTO-SCCM.im1.mfg.hpicorp.net"
            ErrorAction  = "Stop"
        }
        
        $im1Systems = Get-WmiObject @im1Query
        
        foreach ($system in $im1Systems) {
            $DnsHash.Cache.SCCMData[$system.Name] = @{
                Name       = $system.Name
                FQDN       = $system.FullDomainName
                IPs        = $system.IPAddresses
                Domain     = "IM1"
                Source     = "SCCM-IM1"
                LastUpdate = Get-Date
            }
        }
        Write-Verbose "IM1 SCCM Query: Found $($im1Systems.Count) systems"
    }
    catch {
        Write-Warning "IM1 SCCM Query failed: $_"
        Add-DNSValidationError -Target "IM1-SCCM" -ErrorRecord $_ -Operation "SCCM-Query" -Severity "Warning" -Component "Query-SCCMServers"
    }

    # Query CVS Domain
    try {
        Write-Progress -Activity "SCCM Query" -Status "Querying CVS SCCM" -PercentComplete 75
        
        $cvsQuery = @{
            Query        = "Select Name, IPAddresses, ResourceID, FullDomainName from SMS_R_System"
            Namespace    = "root\sms\site_AM1"
            ComputerName = "AM1-SCCM01-COR.rd.hpicorp.net"
            ErrorAction  = "Stop"
        }
        
        $cvsSystems = Get-WmiObject @cvsQuery
        
        foreach ($system in $cvsSystems) {
            if (-not $DnsHash.Cache.SCCMData.ContainsKey($system.Name)) {
                $DnsHash.Cache.SCCMData[$system.Name] = @{
                    Name       = $system.Name
                    FQDN       = $system.FullDomainName
                    IPs        = $system.IPAddresses
                    Domain     = "CVS"
                    Source     = "SCCM-CVS"
                    LastUpdate = Get-Date
                }
            }
        }
        Write-Verbose "CVS SCCM Query: Found $($cvsSystems.Count) systems"
    }
    catch {
        Write-Warning "CVS SCCM Query failed: $_"
        Add-DNSValidationError -Target "CVS-SCCM" -ErrorRecord $_ -Operation "SCCM-Query" -Severity "Warning" -Component "Query-SCCMServers"
    }

    Write-Progress -Activity "SCCM Query" -Status "Complete" -PercentComplete 100
    Write-Verbose "Total SCCM systems found: $($DnsHash.Cache.SCCMData.Count)"
    return $DnsHash.Cache.SCCMData.Count -gt 0
}