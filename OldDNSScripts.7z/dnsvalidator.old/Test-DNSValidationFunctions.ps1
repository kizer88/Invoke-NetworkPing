function Test-PrimaryDomainResolution {
    [CmdletBinding()]
    param([hashtable]$Result)
    
    $Component = $MyInvocation.MyCommand

    try {
        $DnsHash.validation = @{
            Type       = 'PrimaryDomain'
            Status     = 'Processing'
            Confidence = 0
            Details    = @{
                DNSServers         = @{}
                TrustChain         = @()
                AuthStatus         = @{}
                CrossDomainResults = @{}
                ReplicationState   = @{}
                ValidationChain    = [System.Collections.ArrayList]::new()
            }
        }

        # 1. Trust Chain Validation
        $trustChain = Test-DomainTrustChain -Domain $Result.Domain
        $DnsHash.validation.Details.TrustChain = $trustChain
        if (-not $trustChain.IsValid) {
            Write-Warning "Trust chain validation failed for $($Result.Domain)"
            $DnsHash.validation.Confidence = 20
        }

        # 2. AUTH DNS Verification
        $authVerification = Test-AuthDNSRecords -Target $Result.Target -Domain $Result.Domain
        $DnsHash.validation.Details.AuthStatus = $authVerification
        if ($authVerification.HasConflicts) {
            Write-Warning "AUTH DNS conflicts detected for $($Result.Target)"
            $DnsHash.validation.Confidence = [Math]::Min($DnsHash.validation.Confidence, 40)
        }

        # 3. Cross-Domain Resolution
        $crossDomainResults = Test-CrossDomainResolution -Target $Result.Target
        $DnsHash.validation.Details.CrossDomainResults = $crossDomainResults
        [void]$DnsHash.validation.Details.ValidationChain.Add(@{
                Type      = 'CrossDomain'
                Status    = $crossDomainResults.Status
                Timestamp = Get-Date
            })

        # 4. Replication Status
        $replStatus = Test-ReplicationStatus -Domain $Result.Domain
        $DnsHash.validation.Details.ReplicationState = $replStatus
        if ($replStatus.State -eq 'Critical') {
            Write-Warning "Critical replication delay detected"
            $DnsHash.validation.Confidence = [Math]::Min($DnsHash.validation.Confidence, 30)
        }

        # 5. Trust Path Validation
        $trustPath = Test-TrustPathIntegrity -Domain $Result.Domain
        [void]$DnsHash.validation.Details.ValidationChain.Add(@{
                Type      = 'TrustPath'
                Status    = $trustPath.Status
                Path      = $trustPath.Path
                Timestamp = Get-Date
            })

        # 6. Domain Transition Tests
        $transitionState = Test-DomainTransitionState -Domain $Result.Domain
        if ($transitionState.InTransition) {
            Write-Warning "Domain transition in progress for $($Result.Domain)"
            $DnsHash.validation.Confidence = [Math]::Min($DnsHash.validation.Confidence, 50)
        }

        # 7. Validation Chain Integrity
        $chainIntegrity = Test-ValidationChainIntegrity -ValidationChain $DnsHash.validation.Details.ValidationChain
        if (-not $chainIntegrity.IsValid) {
            Write-Warning "Validation chain integrity check failed"
            $DnsHash.validation.Confidence = [Math]::Min($DnsHash.validation.Confidence, 30)
        }

        # Process DNS server results
        foreach ($dnsServer in $Result.Forward.Keys) {
            try {
                $DnsHash.validation.Details.DNSServers[$dnsServer] = @{
                    ForwardIP   = $Result.Forward[$dnsServer]
                    ReverseHost = $Result.Reverse[$Result.Forward[$dnsServer]]
                    QueryTime   = $Result.TimingData[$dnsServer]
                    Status      = if ($Result.Reverse[$Result.Forward[$dnsServer]] -match $Result.Target) { 'Match' } else { 'Mismatch' }
                }
            }
            catch {
                Add-DNSValidationError -Target $Result.Target -ErrorRecord $_ -Operation "DNS-Primary-Resolution" -Component $Component
            }
        }

        # Calculate final confidence based on all checks
        $DnsHash.validation.Confidence = if ($DnsHash.validation.Confidence -eq 0) {
            switch ($DnsHash.validation.Details.DNSServers.Values.Status) {
                { $_ -contains 'Match' } { 80 }
                { $_ -contains 'Mismatch' } { 20 }
                default { 0 }
            }
        }

        $DnsHash.validation.Status = if ($DnsHash.validation.Confidence -ge 80) { 'Success' } 
        elseif ($DnsHash.validation.Confidence -ge 50) { 'Warning' }
        else { 'Failed' }

        return $DnsHash.validation
    }
    catch {
        Add-DNSValidationError -Target $Result.Target -ErrorRecord $_ -Operation "Primary-Domain-Validation" -Severity "Critical" -Component $Component
        return @{ 
            Type       = 'PrimaryDomain'
            Status     = 'Failed'
            Confidence = 0
            Details    = @{} 
        }
    }
}

# Helper Functions
function Test-DomainTrustChain {
    [CmdletBinding()]
    param([string]$Domain)
    
    try {
        $trustChain = @{
            IsValid          = $true
            Chain            = @()
            LastValidated    = Get-Date
            ValidationErrors = @()
        }

        $currentDomain = $Domain
        while ($currentDomain -ne $null) {
            $trustInfo = Get-ADTrust -Domain $currentDomain -ErrorAction Stop
            $trustChain.Chain += @{
                Domain         = $currentDomain
                TrustType      = $trustInfo.TrustType
                TrustDirection = $trustInfo.TrustDirection
                Validated      = Get-Date
            }
            $currentDomain = $trustInfo.ParentDomain
        }

        return $trustChain
    }
    catch {
        return @{
            IsValid          = $false
            Chain            = @()
            LastValidated    = Get-Date
            ValidationErrors = @($_.Exception.Message)
        }
    }
}

function Test-ValidationChainIntegrity {
    [CmdletBinding()]
    param([System.Collections.ArrayList]$ValidationChain)
    
    $integrity = @{
        IsValid   = $true
        Checks    = @()
        Timestamp = Get-Date
    }

    foreach ($validation in $ValidationChain) {
        $check = @{
            Type      = $validation.Type
            Status    = $validation.Status
            Timestamp = $validation.Timestamp
            IsValid   = $true
        }

        if ($validation.Status -eq 'Failed') {
            $check.IsValid = $false
            $integrity.IsValid = $false
        }

        $integrity.Checks += $check
    }

    return $integrity
}