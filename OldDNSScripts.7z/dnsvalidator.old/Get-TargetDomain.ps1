function Get-TargetDomain {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Target,
        
        [Parameter()]
        [switch]$IncludeConfidence,
        
        [Parameter()]
        [switch]$ValidateTrust
    )

    $Component = $MyInvocation.MyCommand
    
    try {
        # Initialize result object
        $domainResult = @{
            Domain         = $null
            Confidence     = 0
            ValidationPath = @()
            TrustStatus    = $null
        }

        # Check for direct domain match first
        foreach ($domain in $serversdomains.Keys) {
            if ($Target -like "*$($serversdomains[$domain].DNSSuffix)") {
                $domainResult.Domain = $domain
                $domainResult.Confidence = 100
                break
            }
        }

        # If no direct match, try DNS resolution
        if (-not $domainResult.Domain) {
            try {
                $dnsResolution = Resolve-DnsName -Name $Target -ErrorAction Stop
                foreach ($domain in $serversdomains.Keys) {
                    if ($dnsResolution.NameHost -like "*$($serversdomains[$domain].DNSSuffix)") {
                        $domainResult.Domain = $domain
                        $domainResult.Confidence = 80
                        break
                    }
                }
            }
            catch {
                Write-Verbose "DNS resolution failed for $Target"
            }
        }

        # Validate trust if requested
        if ($ValidateTrust -and $domainResult.Domain) {
            $trustValidation = Test-TrustChainIntegrity -Result @{
                Domain = $domainResult.Domain
                Target = $Target
            }
            $domainResult.TrustStatus = $trustValidation
            
            # Adjust confidence based on trust validation
            if (-not $trustValidation.IsValid) {
                $domainResult.Confidence = [Math]::Max(($domainResult.Confidence - 30), 0)
            }
        }

        # Add validation path
        $domainResult.ValidationPath = @(
            @{
                Step       = "Initial Check"
                Result     = if ($domainResult.Domain) { "Found" } else { "NotFound" }
                Confidence = $domainResult.Confidence
                Timestamp  = Get-Date
            }
        )

        # Warning for low confidence results
        if ($domainResult.Confidence -lt 50 -and $domainResult.Domain) {
            Write-Warning ("Low confidence domain detection for {0}: {1}" -f $Target, $domainResult.Domain)
        }

        if ($IncludeConfidence) {
            return $domainResult
        }
        else {
            return $domainResult.Domain
        }
    }
    catch {
        Add-DNSValidationError -Target $Target `
            -ErrorRecord $_ `
            -Operation "Domain-Detection" `
            -Severity "Warning" `
            -Component $Component
        return $null
    }
}
